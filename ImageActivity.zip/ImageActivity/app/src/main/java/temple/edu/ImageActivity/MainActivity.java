package temple.edu.ImageActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ImageView imageView;
    Spinner spinner;

    TextView textView;

    int[] dogImagesArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        imageView = findViewById(R.id.imageView);

        textView = findViewById(R.id.textView);

        ArrayList dogArray = new ArrayList<String>();
        dogArray.add(0, "Click here" + "\n" + "Name, description, and picture of dog shown.");
        dogArray.add("Labrador Retriever" + "\n" + "This dog loves swimming.");
        dogArray.add("Pug" + "\n" + "This dog loves sleeping.");
        dogArray.add("Husky" + "\n" + "This dog loves the cold.");
        dogArray.add("Great Dane" + "\n" + "This dog loves leaning.");
        dogArray.add("Bernese Mountain Dog" + "\n" + "This dog loves snow.");

        dogImagesArray = new int[]{R.drawable.white, R.drawable.labrador, R.drawable.pug, R.drawable.husky, R.drawable.dane, R.drawable.bernese};

        ImageAdapter adapter = new ImageAdapter(this, dogArray, dogImagesArray);

        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, "Item Selected", Toast.LENGTH_SHORT).show();
                showPicture(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

                Toast.makeText(MainActivity.this, "Item Unselected", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void showPicture (int position) {
        imageView.setImageResource(dogImagesArray[position]);
    }
}