package temple.edu.ImageActivity;

import android.content.Context;
import android.util.Pair;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class ImageAdapter extends BaseAdapter {

    Context context;
    ArrayList<String> items;
    int[] imageRes;

    public ImageAdapter (Context context, ArrayList items, int[] imageRes) {
        this.context = context;
        this.items = items;
        this.imageRes = imageRes;
    }


    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LinearLayout linearLayout;

        ImageView imageView;
        TextView dogTextView;

        if (convertView == null) {
            linearLayout = new LinearLayout(context);
            imageView = new ImageView(context);
            dogTextView = new TextView(context);

            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            dogTextView.setTextSize(22);
            dogTextView.setPadding(150, 8, 0, 8);

            linearLayout.addView(imageView);
            linearLayout.addView(dogTextView);


            imageView.getLayoutParams().height = 200;
            imageView.getLayoutParams().width = 200;
        } else {
            linearLayout = (LinearLayout) convertView;
            dogTextView = (TextView) linearLayout.getChildAt(1);
            imageView = (ImageView) linearLayout.getChildAt(0);
        }


        dogTextView.setText(items.get(position));
        imageView.setImageResource(imageRes[position]);

        return linearLayout;
    }


    }

